import React, { useState, useEffect } from 'react'
import { Clock, Users, TrendingUp, Calendar, AlertCircle, Circle, RefreshCw, CheckCircle } from 'lucide-react'
import { formatDistanceToNow, isAfter, parseISO, format } from 'date-fns'
import { fr } from 'date-fns/locale'

const Dashboard = ({ tasks, users, onlineUsers, taskCounts }) => {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const overdueTasks = tasks.filter(task => 
    task.dueDate && 
    isAfter(new Date(), parseISO(task.dueDate)) && 
    task.status !== 'done'
  )

  const urgentTasks = tasks.filter(task => {
    if (!task.dueDate || task.status === 'done') return false
    const dueDate = parseISO(task.dueDate)
    const daysDiff = Math.ceil((dueDate - new Date()) / (1000 * 60 * 60 * 24))
    return daysDiff <= 2 && daysDiff >= 0
  })

  const recentTasks = tasks
    .filter(task => task.status !== 'done')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5)

  const getStatusColor = (status) => {
    const colors = {
      todo: 'text-gray-600 bg-gray-100 dark:bg-gray-800 dark:text-gray-300',
      doing: 'text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-200',
      done: 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200'
    }
    return colors[status] || colors.todo
  }

  const getProgressPercentage = () => {
    const total = tasks.length
    if (total === 0) return 0
    return Math.round((taskCounts.done / total) * 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
              Dashboard Collaboratif
            </h1>
            <p className="text-gray-600 dark:text-gray-400 text-lg">
              Vue d'ensemble des tâches en temps réel
            </p>
          </div>
          
          <div className="text-right">
            <div className="text-3xl font-mono text-blue-600 dark:text-blue-400">
              {format(currentTime, 'HH:mm:ss')}
            </div>
            <div className="text-gray-600 dark:text-gray-400">
              {format(currentTime, 'EEEE d MMMM yyyy', { locale: fr })}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 dark:text-gray-400 text-sm font-medium uppercase tracking-wide">
                  À faire
                </p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {taskCounts.todo}
                </p>
              </div>
              <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded-lg">
                <Clock className="text-gray-600 dark:text-gray-400" size={24} />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 dark:text-blue-400 text-sm font-medium uppercase tracking-wide">
                  En cours
                </p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {taskCounts.doing}
                </p>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-lg">
                <TrendingUp className="text-blue-600 dark:text-blue-400" size={24} />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 dark:text-green-400 text-sm font-medium uppercase tracking-wide">
                  Terminé
                </p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {taskCounts.done}
                </p>
              </div>
              <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg">
                <Calendar className="text-green-600 dark:text-green-400" size={24} />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 dark:text-purple-400 text-sm font-medium uppercase tracking-wide">
                  En ligne
                </p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {onlineUsers.length}
                </p>
              </div>
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-lg">
                <Users className="text-purple-600 dark:text-purple-400" size={24} />
              </div>
            </div>
          </div>
        </div>

        {/* Progress and Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Progress */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Progression globale
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600 dark:text-gray-400">Avancement</span>
                <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {getProgressPercentage()}%
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-4 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${getProgressPercentage()}%` }}
                ></div>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {taskCounts.done} sur {tasks.length} tâches terminées
              </div>
            </div>
          </div>

          {/* Alerts */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <AlertCircle className="text-red-500" size={24} />
              Alertes
            </h3>
            <div className="space-y-3">
              {overdueTasks.length > 0 && (
                <div className="flex items-center gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <div className="text-red-600 dark:text-red-400">
                    <strong>{overdueTasks.length}</strong> tâche(s) en retard
                  </div>
                </div>
              )}
              
              {urgentTasks.length > 0 && (
                <div className="flex items-center gap-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <div className="text-orange-600 dark:text-orange-400">
                    <strong>{urgentTasks.length}</strong> tâche(s) urgente(s)
                  </div>
                </div>
              )}
              
              {overdueTasks.length === 0 && urgentTasks.length === 0 && (
                <div className="text-green-600 dark:text-green-400 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  ✅ Aucune alerte
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tasks and Team */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Tasks */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Tâches récentes
            </h3>
            <div className="space-y-3">
              {recentTasks.length > 0 ? recentTasks.map((task) => {
                const isOverdue = task.dueDate && isAfter(new Date(), parseISO(task.dueDate))
                
                return (
                  <div
                    key={task.id}
                    className={`p-4 rounded-lg border-l-4 ${
                      isOverdue 
                        ? 'border-red-500 bg-red-50 dark:bg-red-900/20' 
                        : task.status === 'doing'
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-300 bg-gray-50 dark:bg-gray-700/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900 dark:text-white truncate">
                        {task.title}
                      </h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium inline-flex items-center gap-1 ${getStatusColor(task.status)}`}>
                        {/* Mobile: icon only */}
                        <span className="md:hidden inline-flex items-center">
                          {task.status === 'todo' && <Circle size={12} />}
                          {task.status === 'doing' && <RefreshCw size={12} />}
                          {task.status === 'done' && <CheckCircle size={12} />}
                          <span className="sr-only">{task.status === 'todo' ? 'À faire' : task.status === 'doing' ? 'En cours' : 'Terminé'}</span>
                        </span>
                        {/* Desktop: text label */}
                        <span className="hidden md:inline">
                          {task.status === 'todo' ? 'À faire' : task.status === 'doing' ? 'En cours' : 'Terminé'}
                        </span>
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center gap-2">
                        {task.assignee && (
                          <span>{task.assignee.avatar} {task.assignee.name}</span>
                        )}
                      </div>
                      {task.dueDate && (
                        <span className={isOverdue ? 'text-red-600 dark:text-red-400' : ''}>
                          {formatDistanceToNow(parseISO(task.dueDate), { 
                            addSuffix: true, 
                            locale: fr 
                          })}
                        </span>
                      )}
                    </div>
                  </div>
                )
              }) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <Clock size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Aucune tâche récente</p>
                </div>
              )}
            </div>
          </div>

          {/* Team Status */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Équipe
            </h3>
            <div className="space-y-3">
              {users.map((user) => {
                const isOnline = onlineUsers.some(ou => ou.id === user.id)
                const userTasks = tasks.filter(task => task.assigneeId === user.id && task.status !== 'done')
                
                return (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <span className="text-2xl">{user.avatar}</span>
                        {isOnline && (
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
                        )}
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900 dark:text-white">
                          {user.name}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <span className="hidden md:inline">{isOnline ? 'En ligne' : 'Hors ligne'}</span>
                          <span className="sr-only md:not-sr-only md:hidden">{isOnline ? 'En ligne' : 'Hors ligne'}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                        {userTasks.length}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        tâche(s)
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard