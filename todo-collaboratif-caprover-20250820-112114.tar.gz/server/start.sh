#!/bin/sh
set -e

echo "Initializing database..."
npx prisma generate
npx prisma db push
npm run db:seed

echo "Starting application..."
exec node src/server.js