const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

const prisma = new PrismaClient();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Serve static files from the React app build
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/users', require('./routes/users'));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Serve React app for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Socket.io connection handling
const connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('user:join', async (userId) => {
    try {
      connectedUsers.set(socket.id, userId);
      
      await prisma.user.update({
        where: { id: userId },
        data: { isOnline: true }
      });

      const onlineUsers = await prisma.user.findMany({
        where: { isOnline: true },
        select: { id: true, name: true, avatar: true }
      });

      io.emit('users:online', onlineUsers);
    } catch (error) {
      console.error('Error joining user:', error);
    }
  });

  socket.on('disconnect', async () => {
    const userId = connectedUsers.get(socket.id);
    if (userId) {
      try {
        await prisma.user.update({
          where: { id: userId },
          data: { isOnline: false }
        });

        connectedUsers.delete(socket.id);

        const onlineUsers = await prisma.user.findMany({
          where: { isOnline: true },
          select: { id: true, name: true, avatar: true }
        });

        io.emit('users:online', onlineUsers);
      } catch (error) {
        console.error('Error disconnecting user:', error);
      }
    }
    console.log('User disconnected:', socket.id);
  });
});

// Make io accessible to routes
app.set('io', io);

// Graceful shutdown
process.on('SIGTERM', async () => {
  await prisma.$disconnect();
  server.close();
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});