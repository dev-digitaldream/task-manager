import React, { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Moon, Sun, Users, Download, Settings, LogOut } from 'lucide-react'
import TaskList from './components/TaskList'
import Dashboard from './components/Dashboard'
import LoginForm from './components/LoginForm'
import UserManagement from './components/UserManagement'
import { useSocket } from './hooks/useSocket'
import { useTasks } from './hooks/useTasks'
import { useUsers } from './hooks/useUsers'

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true'
  })
  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem('currentUser')
    return saved ? JSON.parse(saved) : null
  })
  const [showUserManagement, setShowUserManagement] = useState(false)

  const { socket } = useSocket(currentUser?.id)
  const { tasks, createTask, updateTask, deleteTask, addComment } = useTasks(socket)
  const { users, onlineUsers } = useUsers(socket)

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
    localStorage.setItem('darkMode', darkMode)
  }, [darkMode])

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser))
    }
  }, [currentUser])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
  }

  const exportData = async () => {
    try {
      const response = await fetch('/api/users/export')
      const data = await response.json()
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { 
        type: 'application/json' 
      })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `todo-export-${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Export failed:', error)
    }
  }

  const getTaskCounts = () => {
    return {
      todo: tasks.filter(t => t.status === 'todo').length,
      doing: tasks.filter(t => t.status === 'doing').length,
      done: tasks.filter(t => t.status === 'done').length
    }
  }

  const handleLogin = (user) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem('currentUser')
  }

  // Public dashboard: we no longer gate the whole app on login.

  const taskCounts = getTaskCounts()

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Routes>
        <Route path="/dashboard" element={
          <Dashboard 
            tasks={tasks}
            users={users}
            onlineUsers={onlineUsers}
            taskCounts={taskCounts}
          />
        } />
        
        <Route path="/" element={
          currentUser ? (
          <div className="container mx-auto px-4 py-6 max-w-4xl">
            <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
              <div className="flex items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Todo Collaboratif
                </h1>
                
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users size={16} />
                  <span>{onlineUsers.length} en ligne</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <span className="status-indicator status-todo">
                    À faire: {taskCounts.todo}
                  </span>
                  <span className="status-indicator status-doing">
                    En cours: {taskCounts.doing}
                  </span>
                  <span className="status-indicator status-done">
                    Terminé: {taskCounts.done}
                  </span>
                </div>

                <button
                  onClick={exportData}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  title="Exporter les données"
                >
                  <Download size={20} className="text-gray-600 dark:text-gray-400" />
                </button>

                <button
                  onClick={() => setShowUserManagement(true)}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  title="Gestion des utilisateurs"
                >
                  <Settings size={20} className="text-gray-600 dark:text-gray-400" />
                </button>

                <button
                  onClick={toggleDarkMode}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  {darkMode ? (
                    <Sun size={20} className="text-yellow-500" />
                  ) : (
                    <Moon size={20} className="text-gray-600" />
                  )}
                </button>

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 px-2 py-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <LogOut size={16} />
                  Déconnexion
                </button>
              </div>
            </header>

            <div className="mb-6 p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium text-gray-900 dark:text-white">
                  Connecté en tant que:
                </span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {currentUser.avatar} {currentUser.name}
                </span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <span>Utilisateurs en ligne:</span>
                <div className="flex gap-1">
                  {onlineUsers.map(user => (
                    <span key={user.id} className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full text-xs">
                      {user.avatar} {user.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <TaskList
              tasks={tasks}
              users={users}
              currentUser={currentUser}
              onCreateTask={createTask}
              onUpdateTask={updateTask}
              onDeleteTask={deleteTask}
              onAddComment={addComment}
            />
          </div>
          ) : (
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
              <LoginForm 
                onLogin={handleLogin}
                darkMode={darkMode}
                onToggleDarkMode={toggleDarkMode}
              />
            </div>
          )
        } />
      </Routes>

      {showUserManagement && (
        <UserManagement 
          currentUser={currentUser}
          onClose={() => setShowUserManagement(false)}
        />
      )}
    </div>
  )
}

export default App