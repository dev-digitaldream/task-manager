import React, { useState } from 'react'
import { Calendar, User, MessageCircle, Edit, Trash2, Clock, Circle, RefreshCw, CheckCircle, Info } from 'lucide-react'
import { formatDistanceToNow, isAfter, parseISO } from 'date-fns'
import { fr } from 'date-fns/locale'
import CommentSection from './CommentSection'

const TaskItem = ({ task, users, currentUser, onUpdate, onDelete, onEdit, onAddComment }) => {
  const [showComments, setShowComments] = useState(false)

  const isOverdue = task.dueDate && isAfter(new Date(), parseISO(task.dueDate))
  const priority = task.priority || 'medium'
  const clientApproval = task.clientApproval || 'none'
  const approvalComment = task.approvalComment || ''
  
  const getStatusLabel = (status) => {
    const labels = {
      todo: 'À faire',
      doing: 'En cours', 
      done: 'Terminé'
    }
    return labels[status] || status
  }

  const getStatusClass = (status) => {
    return `status-indicator status-${status}`
  }

  const getPriorityBadgeClass = (p) => {
    const map = {
      low: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200',
      medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      high: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      urgent: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
    }
    return `px-2 py-0.5 rounded-full text-xs font-medium ${map[p] || map.medium}`
  }

  const getApprovalBadgeClass = (a) => {
    const map = {
      none: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200',
      pending: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      approved: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      rejected: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
    }
    return `px-2 py-0.5 rounded-full text-xs font-medium ${map[a] || map.none}`
  }

  const handleStatusChange = async (newStatus) => {
    try {
      await onUpdate(task.id, { status: newStatus })
    } catch (error) {
      console.error('Failed to update status:', error)
    }
  }

  const handleDelete = async () => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?')) {
      try {
        await onDelete(task.id)
      } catch (error) {
        console.error('Failed to delete task:', error)
      }
    }
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg border transition-colors ${
      isOverdue && task.status !== 'done' 
        ? 'task-overdue border-red-200 dark:border-red-800' 
        : 'border-gray-200 dark:border-gray-700'
    }`}>
      <div className="p-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {task.title}
              </h3>
              <span className={getPriorityBadgeClass(priority)} title={`Priority: ${priority}`}>
                Priority: {priority}
              </span>
              <span className={getApprovalBadgeClass(clientApproval)} title={`Client: ${clientApproval}${approvalComment ? ` — ${approvalComment}` : ''}`}>
                Client: {clientApproval}
              </span>
            
              {isOverdue && task.status !== 'done' && (
                <div className="flex items-center gap-1 text-red-600 dark:text-red-400 text-sm">
                  <Clock size={14} />
                  {/* Mobile: icon only, keep accessible label */}
                  <span className="sr-only md:not-sr-only md:inline">En retard</span>
                </div>
              )}
            </div>

            {approvalComment && (
              <div className="mt-2 text-xs text-gray-600 dark:text-gray-400 flex items-start gap-1">
                <Info size={12} className="mt-0.5" />
                <span>{approvalComment}</span>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
              {task.assignee && (
                <div className="flex items-center gap-1">
                  <User size={14} />
                  <span>{task.assignee.avatar} {task.assignee.name}</span>
                </div>
              )}

              {task.dueDate && (
                <div className="flex items-center gap-1">
                  <Calendar size={14} />
                  <span className={isOverdue && task.status !== 'done' ? 'text-red-600 dark:text-red-400' : ''}>
                    {formatDistanceToNow(parseISO(task.dueDate), { 
                      addSuffix: true, 
                      locale: fr 
                    })}
                  </span>
                </div>
              )}

              {task.comments?.length > 0 && (
                <button
                  onClick={() => setShowComments(!showComments)}
                  className="flex items-center gap-1 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  <MessageCircle size={14} />
                  <span>{task.comments.length}</span>
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={task.status}
              onChange={(e) => handleStatusChange(e.target.value)}
              className="px-3 py-1 rounded-lg text-sm border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="todo">À faire</option>
              <option value="doing">En cours</option>
              <option value="done">Terminé</option>
            </select>

            <button
              onClick={onEdit}
              className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              title="Modifier"
            >
              <Edit size={16} />
            </button>

            <button
              onClick={handleDelete}
              className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
              title="Supprimer"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className={`${getStatusClass(task.status)} inline-flex items-center gap-1`}>
            {/* Mobile: icon only */}
            <span className="md:hidden inline-flex items-center">
              {task.status === 'todo' && <Circle size={14} />}
              {task.status === 'doing' && <RefreshCw size={14} />}
              {task.status === 'done' && <CheckCircle size={14} />}
            </span>
            {/* Desktop: text label */}
            <span className="hidden md:inline">
              {getStatusLabel(task.status)}
            </span>
          </span>

          <div className="text-xs text-gray-500 dark:text-gray-400">
            Créé {formatDistanceToNow(parseISO(task.createdAt), { 
              addSuffix: true, 
              locale: fr 
            })}
          </div>
        </div>
      </div>

      {(showComments || task.comments?.length === 0) && (
        <CommentSection
          taskId={task.id}
          comments={task.comments || []}
          currentUser={currentUser}
          onAddComment={onAddComment}
        />
      )}
    </div>
  )
}

export default TaskItem