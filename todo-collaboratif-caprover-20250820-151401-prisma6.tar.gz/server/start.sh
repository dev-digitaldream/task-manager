#!/bin/sh
set -e

echo "Initializing database..."
npx prisma generate
npx prisma db push

# Seed only if explicitly enabled (avoid wiping prod data)
if [ "${SEED:-false}" = "true" ]; then
  echo "Seeding enabled (SEED=true), running seed script..."
  npm run db:seed
else
  echo "Seeding skipped (SEED not true)."
fi

echo "Starting application..."
exec node src/server.js